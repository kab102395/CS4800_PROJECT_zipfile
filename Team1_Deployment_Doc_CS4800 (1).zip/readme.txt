- Login UI: invisible text; case-sensitive; requires Enter then ESC.
- Runner visuals: placeholder sprites/background; clean-up needed.
- Runner stats: score save confirmed; stats sometimes lag - use exact username; backend now aggregates missing stats.
- ESC behavior: previously exited unexpectedly; monitor after proxy/name fixes.

