components {
  id: "gui"
  component: "/main/gameobjects/login.gui"
}
