components {
  id: "script"
  component: "/main/scripts/relay.script"
}
