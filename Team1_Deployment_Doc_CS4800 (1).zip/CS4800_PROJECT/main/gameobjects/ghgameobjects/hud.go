components {
  id: "gui"
  component: "/main/gameobjects/ghgameobjects/hud.gui"
}
