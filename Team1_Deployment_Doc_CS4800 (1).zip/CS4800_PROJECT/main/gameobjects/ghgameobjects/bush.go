embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"Bush\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/atlases/ghatlases/environment.atlas\"\n"
  "}\n"
  ""
  position {
    z: 1.0
  }
}
