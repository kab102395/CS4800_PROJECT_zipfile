components {
  id: "gui"
  component: "/main/spaceShooterGame-main/main/main.gui"
}
components {
  id: "script"
  component: "/main/spaceShooterGame-main/main/main.script"
}
