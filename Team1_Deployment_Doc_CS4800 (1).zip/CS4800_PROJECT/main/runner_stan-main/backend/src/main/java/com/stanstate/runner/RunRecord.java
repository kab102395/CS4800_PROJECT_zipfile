package com.stanstate.runner;

public record RunRecord(long id, String player, int score, int coins, String createdAt) {
}

