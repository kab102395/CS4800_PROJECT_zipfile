components {
  id: "script"
  component: "/main/ttt/ttt_input.script"
}
